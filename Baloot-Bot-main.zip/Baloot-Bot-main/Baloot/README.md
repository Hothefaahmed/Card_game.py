# Baloot Bots
<strong>*Still in progress*!</strong><br><hr>
This is The Senior Project for Spring 2022 in Faculty of Computing and Information Technology in King Abdul-Aziz University.
<br>A playable (Baloot) card game in Python language using Reinforcement Learning.

.<br>
.<br>
.

Credit to our Supervisor:<br>
-Dr. Rayan Mosli

And my Friends who are also my colleagues that helped me in this project, which you will find their information in the GitHub accounts below:
<br>@MohammedA23
<br>@CodeManJoe
