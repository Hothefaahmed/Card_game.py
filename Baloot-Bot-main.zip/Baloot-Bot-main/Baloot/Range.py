class Range:
    def __init__(self, RangeMin=None, RangeMax=None):
        self.Min = RangeMin
        self.Max = RangeMax