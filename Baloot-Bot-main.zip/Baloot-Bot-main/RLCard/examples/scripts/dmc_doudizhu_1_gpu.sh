python3 examples/run_dmc.py --env doudizhu --xpid doudizhu --cuda 0 --num_actor_devices 1 --training_device 0 --num_actors 8 --save_interval 30
