name = "rlcard"
__version__ = "1.0.7"

from rlcard.envs import make
