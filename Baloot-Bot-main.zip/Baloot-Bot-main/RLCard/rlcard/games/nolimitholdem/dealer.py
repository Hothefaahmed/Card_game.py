from rlcard.games.limitholdem import Dealer


class NolimitholdemDealer(Dealer):
    pass
