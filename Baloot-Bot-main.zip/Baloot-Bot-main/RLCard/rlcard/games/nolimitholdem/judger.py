from rlcard.games.limitholdem import Judger


class NolimitholdemJudger(Judger):
    pass
